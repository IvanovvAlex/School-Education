﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.IO;

namespace _2ex
{
    class Program
    {
        static void Main(string[] args)
        {
            Random rnd = new Random();
            int n = rnd.Next(11, 130);

            string cDirs = @"D:\School\School-Education\OOP\190321\2ex";
            for (int i = 0; i < n; i++)
            {
                int result = rnd.Next(0, 100);

                using (StreamWriter outputFile = new StreamWriter(Path.Combine(cDirs, "Results.txt"), true))
                {
                    outputFile.Write(result + " ");
                }
            }
            
            List<int> results = new List<int>();
            for (int i = 0; i < n; i++)
            {
                using (StreamReader inputFile = new StreamReader(Path.Combine(cDirs, "Results.txt"), true))
                {
                    
                        string input = inputFile.ReadLine();
                    inputFile.Close();
                    results = input
                        .Split(" ", StringSplitOptions.RemoveEmptyEntries)
                        .Select(int.Parse)
                        .ToList();
                   
                }
            }
            int counter = 1;
            foreach (var result in results.OrderByDescending(x => x))
            {
                if (counter == 11)
                {
                    break;
                }
                else
                {
                    Console.WriteLine($"{counter} mqsto- {result} tochki");
                    counter++;
                }
            }
            using (FileStream fs = new FileStream(cDirs + @"\Results.txt", FileMode.Truncate))
            {
            }
        }
    }
}
