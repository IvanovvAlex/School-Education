﻿namespace FDMC.Models
{
    public class EditFormCatViewModel
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public string BreedId { get; set; }
        public string ImageUrl { get; set; }
    }
}
