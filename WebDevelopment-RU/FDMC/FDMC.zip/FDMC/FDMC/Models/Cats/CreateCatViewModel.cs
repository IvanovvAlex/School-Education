﻿namespace FDMC.Models
{
    public class CreateCatViewModel
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public string BreedId { get; set; }
        public string ImageUrl { get; set; }
    }
}
