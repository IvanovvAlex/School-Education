﻿namespace FDMC.Models.Breeds
{
    public class CreateBreedFormViewModel
    {
        public string Name { get; set; }
    }
}
