﻿namespace FDMC.Models.Breeds
{
    public class BreedViewModel
    {
        public string Id { get; init; }
        public string Name { get; set; }
    }
}
